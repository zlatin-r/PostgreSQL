create view view_wizard_deposits_with_expiration_date_before_1983_08_17("Wizard Name", "Start Date", "Expiration Date", "Amount") as
SELECT DISTINCT (first_name::text || ' '::text) || last_name::text AS "Wizard Name",
                deposit_start_date                                 AS "Start Date",
                deposit_expiration_date                            AS "Expiration Date",
                deposit_amount                                     AS "Amount"
FROM wizard_deposits
WHERE deposit_expiration_date <= '1983-08-17'::date
GROUP BY ((first_name::text || ' '::text) || last_name::text), deposit_start_date, deposit_expiration_date,
         deposit_amount
ORDER BY deposit_expiration_date;

alter table view_wizard_deposits_with_expiration_date_before_1983_08_17
    owner to postgres;

